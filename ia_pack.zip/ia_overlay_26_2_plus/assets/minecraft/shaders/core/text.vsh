#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>






#define hue(v) ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.))

#define finalize() { texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0.) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

vec4 lightmapped_color(vec4 color) {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    return color*sample_lightmap(Sampler2, UV2);
#else
    return color;
#endif
}

void f_e9bb752e(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_edadddc5() {
    vertexColor=lightmapped_color(Color);
}


void f_57cd10d6(inout vec4 vertex) {
    f_e9bb752e(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_edadddc5();
    }
    finalize();
}



void f_c72e94c0() {
    vertexColor=lightmapped_color(hue(gl_Position.x+safeGameTime()*1000.));
}

void f_d65a660b() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6.)) / 150.;
}

void f_e76aa86a(inout vec4 vertex) {
    f_e9bb752e(vertex);
    f_c72e94c0();
    finalize();
}

void f_4bce2de5(inout vec4 vertex) {
    f_e9bb752e(vertex);
    f_edadddc5();
    f_d65a660b();
    finalize();
}

void f_267f673d(inout vec4 vertex) {
    f_e9bb752e(vertex);
    f_d65a660b();
    f_c72e94c0();
    finalize();
}

void f_3374e217(inout vec4 vertex) {
    f_edadddc5();
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_e9bb752e(vertex);
    finalize();
}

void f_5c1eafcc(inout vec4 vertex) {
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_e9bb752e(vertex);
    f_c72e94c0();
    finalize();
}

void f_cdd38c85(inout vec4 vertex, float speed) {
    f_e9bb752e(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=lightmapped_color(Color*blink);
    finalize();
}



void f_a0725707(inout vec4 vertex) {
    f_e9bb752e(vertex);
    f_edadddc5();
    vertexColor=vec4(1., 1., 1., vertexColor.a);
    finalize();
}


void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
#endif
    f_edadddc5();

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255.+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85)) {
        f_57cd10d6(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9)) {
            gl_Position=vec4(2., 2., 2., 1.);
            f_edadddc5();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            f_e9bb752e(vertex);
            f_edadddc5();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_4bce2de5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            f_4bce2de5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_3374e217(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_3374e217(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_cdd38c85(vertex, .5);
            return;
        }

        
        
    }

    
    
    if(iColor==ivec3(78, 92, 36)) {
        f_a0725707(vertex);
        return;
    }
    

    
    
    if(iColor==ivec3(230, 255, 254)) {
        f_e76aa86a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250)) {
        f_4bce2de5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254)) {
        f_267f673d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250)) {
        f_3374e217(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254)) {
        f_5c1eafcc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250)) {
        f_cdd38c85(vertex, .5);
        return;
    }

    
    

    
    
    if(iColor==ivec3(255, 255, 254)) {
        f_e76aa86a(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 253)) {
        f_4bce2de5(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 252)) {
        f_267f673d(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 251)) {
        f_3374e217(vertex);
        return;
    }

    if(iColor==ivec3(255, 254, 254)) {
        f_5c1eafcc(vertex);
        return;
    }
    

    f_e9bb752e(vertex);
    f_edadddc5();
    finalize();
}