#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>






#define hue(v) ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.))

#define finalize() { texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0.) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

vec4 lightmapped_color(vec4 color) {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    return color*sample_lightmap(Sampler2, UV2);
#else
    return color;
#endif
}

void f_72f65e4c(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_49f90824() {
    vertexColor=lightmapped_color(Color);
}


void f_bab44afc(inout vec4 vertex) {
    f_72f65e4c(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_49f90824();
    }
    finalize();
}



void f_57c76ddb() {
    vertexColor=lightmapped_color(hue(gl_Position.x+safeGameTime()*1000.));
}

void f_b3c10c1f() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6.)) / 150.;
}

void f_009f2001(inout vec4 vertex) {
    f_72f65e4c(vertex);
    f_57c76ddb();
    finalize();
}

void f_fd1ea641(inout vec4 vertex) {
    f_72f65e4c(vertex);
    f_49f90824();
    f_b3c10c1f();
    finalize();
}

void f_4837ea95(inout vec4 vertex) {
    f_72f65e4c(vertex);
    f_b3c10c1f();
    f_57c76ddb();
    finalize();
}

void f_e15e6c71(inout vec4 vertex) {
    f_49f90824();
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_72f65e4c(vertex);
    finalize();
}

void f_a8d29e60(inout vec4 vertex) {
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_72f65e4c(vertex);
    f_57c76ddb();
    finalize();
}

void f_5d6950a7(inout vec4 vertex, float speed) {
    f_72f65e4c(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=lightmapped_color(Color*blink);
    finalize();
}



void f_13466ece(inout vec4 vertex) {
    f_72f65e4c(vertex);
    f_49f90824();
    vertexColor=vec4(1., 1., 1., vertexColor.a);
    finalize();
}


void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
#endif
    f_49f90824();

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255.+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85)) {
        f_bab44afc(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9)) {
            gl_Position=vec4(2., 2., 2., 1.);
            f_49f90824();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            f_72f65e4c(vertex);
            f_49f90824();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_fd1ea641(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            f_fd1ea641(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_e15e6c71(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_e15e6c71(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_5d6950a7(vertex, .5);
            return;
        }

        
        
    }

    
    
    if(iColor==ivec3(78, 92, 36)) {
        f_13466ece(vertex);
        return;
    }
    

    
    
    if(iColor==ivec3(230, 255, 254)) {
        f_009f2001(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250)) {
        f_fd1ea641(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254)) {
        f_4837ea95(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250)) {
        f_e15e6c71(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254)) {
        f_a8d29e60(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250)) {
        f_5d6950a7(vertex, .5);
        return;
    }

    
    

    
    
    if(iColor==ivec3(255, 255, 254)) {
        f_009f2001(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 253)) {
        f_fd1ea641(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 252)) {
        f_4837ea95(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 251)) {
        f_e15e6c71(vertex);
        return;
    }

    if(iColor==ivec3(255, 254, 254)) {
        f_a8d29e60(vertex);
        return;
    }
    

    f_72f65e4c(vertex);
    f_49f90824();
    finalize();
}