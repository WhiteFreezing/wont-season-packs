#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>






#define hue(v) ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.))

#define finalize() { texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0.) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

vec4 lightmapped_color(vec4 color) {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    return color*sample_lightmap(Sampler2, UV2);
#else
    return color;
#endif
}

void f_1ec83c8c(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_433a1c2f() {
    vertexColor=lightmapped_color(Color);
}


void f_23b03db1(inout vec4 vertex) {
    f_1ec83c8c(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_433a1c2f();
    }
    finalize();
}



void f_98c2a4fd() {
    vertexColor=lightmapped_color(hue(gl_Position.x+safeGameTime()*1000.));
}

void f_0676abbd() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6.)) / 150.;
}

void f_f98e465a(inout vec4 vertex) {
    f_1ec83c8c(vertex);
    f_98c2a4fd();
    finalize();
}

void f_5e148b36(inout vec4 vertex) {
    f_1ec83c8c(vertex);
    f_433a1c2f();
    f_0676abbd();
    finalize();
}

void f_44665a68(inout vec4 vertex) {
    f_1ec83c8c(vertex);
    f_0676abbd();
    f_98c2a4fd();
    finalize();
}

void f_62438c72(inout vec4 vertex) {
    f_433a1c2f();
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_1ec83c8c(vertex);
    finalize();
}

void f_187ff644(inout vec4 vertex) {
    float vertexId=mod(float(gl_VertexID), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_1ec83c8c(vertex);
    f_98c2a4fd();
    finalize();
}

void f_cec24300(inout vec4 vertex, float speed) {
    f_1ec83c8c(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=lightmapped_color(Color*blink);
    finalize();
}



void f_272c6c04(inout vec4 vertex) {
    f_1ec83c8c(vertex);
    f_433a1c2f();
    vertexColor=vec4(1., 1., 1., vertexColor.a);
    finalize();
}


void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
#endif
    f_433a1c2f();

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255.+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85)) {
        f_23b03db1(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9)) {
            gl_Position=vec4(2., 2., 2., 1.);
            f_433a1c2f();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            f_1ec83c8c(vertex);
            f_433a1c2f();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_5e148b36(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            f_5e148b36(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_62438c72(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_62438c72(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_cec24300(vertex, .5);
            return;
        }

        
        
    }

    
    
    if(iColor==ivec3(78, 92, 36)) {
        f_272c6c04(vertex);
        return;
    }
    

    
    
    if(iColor==ivec3(230, 255, 254)) {
        f_f98e465a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250)) {
        f_5e148b36(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254)) {
        f_44665a68(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250)) {
        f_62438c72(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254)) {
        f_187ff644(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250)) {
        f_cec24300(vertex, .5);
        return;
    }

    
    

    
    
    if(iColor==ivec3(255, 255, 254)) {
        f_f98e465a(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 253)) {
        f_5e148b36(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 252)) {
        f_44665a68(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 251)) {
        f_62438c72(vertex);
        return;
    }

    if(iColor==ivec3(255, 254, 254)) {
        f_187ff644(vertex);
        return;
    }
    

    f_1ec83c8c(vertex);
    f_433a1c2f();
    finalize();
}