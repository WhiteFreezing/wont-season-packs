#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_a0aced0e(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_22afbac3() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_0e8d2aed(inout vec4 vertex) {
    f_a0aced0e(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_22afbac3();
    }
    finalize();
}



void f_56745229() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_7e9dfdca() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_9ff4e4af(inout vec4 vertex) {
    f_a0aced0e(vertex);
    f_56745229();
    finalize();
}

void f_33e40329(inout vec4 vertex) {
    f_a0aced0e(vertex);
    f_22afbac3();
    f_7e9dfdca();
    finalize();
}

void f_21455ee2(inout vec4 vertex) {
    f_a0aced0e(vertex);
    f_7e9dfdca();
    f_56745229();
    finalize();
}

void f_b5b7dcdf(inout vec4 vertex) {
    f_22afbac3();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a0aced0e(vertex);
    finalize();
}

void f_397b7932(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_56745229();
    f_a0aced0e(vertex);
    finalize();
}

void f_832c2039(inout vec4 vertex, float speed) {
    f_a0aced0e(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_17eca094(inout vec4 vertex) {
    f_a0aced0e(vertex);
    f_22afbac3();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_0e8d2aed(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_22afbac3();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_a0aced0e(vertex);
            f_22afbac3();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_33e40329(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_33e40329(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_b5b7dcdf(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_b5b7dcdf(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_832c2039(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_17eca094(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_9ff4e4af(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_33e40329(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_21455ee2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_b5b7dcdf(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_397b7932(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_832c2039(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_9ff4e4af(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_33e40329(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_21455ee2(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_b5b7dcdf(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_397b7932(vertex);
        return;
    }
    

    
    f_a0aced0e(vertex);
    f_22afbac3();
    finalize();
}