#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_88e122bb(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_8e220900() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_43842124(inout vec4 vertex) {
    f_88e122bb(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_8e220900();
    }
    finalize();
}



void f_1cb2deab() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_7cc4a412() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_0fd89866(inout vec4 vertex) {
    f_88e122bb(vertex);
    f_1cb2deab();
    finalize();
}

void f_cb639697(inout vec4 vertex) {
    f_88e122bb(vertex);
    f_8e220900();
    f_7cc4a412();
    finalize();
}

void f_303edac9(inout vec4 vertex) {
    f_88e122bb(vertex);
    f_7cc4a412();
    f_1cb2deab();
    finalize();
}

void f_0bcac1aa(inout vec4 vertex) {
    f_8e220900();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_88e122bb(vertex);
    finalize();
}

void f_49a1c024(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_1cb2deab();
    f_88e122bb(vertex);
    finalize();
}

void f_4d51b409(inout vec4 vertex, float speed) {
    f_88e122bb(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_b8edd7eb(inout vec4 vertex) {
    f_88e122bb(vertex);
    f_8e220900();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_43842124(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_8e220900();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_88e122bb(vertex);
            f_8e220900();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_cb639697(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_cb639697(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_0bcac1aa(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_0bcac1aa(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_4d51b409(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_b8edd7eb(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_0fd89866(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_cb639697(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_303edac9(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_0bcac1aa(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_49a1c024(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_4d51b409(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_0fd89866(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_cb639697(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_303edac9(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_0bcac1aa(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_49a1c024(vertex);
        return;
    }
    

    
    f_88e122bb(vertex);
    f_8e220900();
    finalize();
}