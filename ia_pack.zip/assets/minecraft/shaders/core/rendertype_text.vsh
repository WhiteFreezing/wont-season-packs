#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_5453c1ca(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_19ac9aa1() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_946e3d50(inout vec4 vertex) {
    f_5453c1ca(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_19ac9aa1();
    }
    finalize();
}



void f_02966c49() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_24b37e54() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_225b99d3(inout vec4 vertex) {
    f_5453c1ca(vertex);
    f_02966c49();
    finalize();
}

void f_c475bc6a(inout vec4 vertex) {
    f_5453c1ca(vertex);
    f_19ac9aa1();
    f_24b37e54();
    finalize();
}

void f_fbbd9460(inout vec4 vertex) {
    f_5453c1ca(vertex);
    f_24b37e54();
    f_02966c49();
    finalize();
}

void f_6e8bb5d9(inout vec4 vertex) {
    f_19ac9aa1();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_5453c1ca(vertex);
    finalize();
}

void f_2c798f59(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_02966c49();
    f_5453c1ca(vertex);
    finalize();
}

void f_4a4fdfcc(inout vec4 vertex, float speed) {
    f_5453c1ca(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_1591fa53(inout vec4 vertex) {
    f_5453c1ca(vertex);
    f_19ac9aa1();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_946e3d50(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_19ac9aa1();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_5453c1ca(vertex);
            f_19ac9aa1();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_c475bc6a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_c475bc6a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_6e8bb5d9(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_6e8bb5d9(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_4a4fdfcc(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_1591fa53(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_225b99d3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_c475bc6a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_fbbd9460(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_6e8bb5d9(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_2c798f59(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_4a4fdfcc(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_225b99d3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_c475bc6a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_fbbd9460(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_6e8bb5d9(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_2c798f59(vertex);
        return;
    }
    

    
    f_5453c1ca(vertex);
    f_19ac9aa1();
    finalize();
}