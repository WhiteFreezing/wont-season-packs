#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_6ff1481c(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_2ff19491() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_ab98f1b1(inout vec4 vertex) {
    f_6ff1481c(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_2ff19491();
    }
    finalize();
}



void f_991f0c6f() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_13044f3d() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_5a9aac0f(inout vec4 vertex) {
    f_6ff1481c(vertex);
    f_991f0c6f();
    finalize();
}

void f_6ad6c92c(inout vec4 vertex) {
    f_6ff1481c(vertex);
    f_2ff19491();
    f_13044f3d();
    finalize();
}

void f_b453f38b(inout vec4 vertex) {
    f_6ff1481c(vertex);
    f_13044f3d();
    f_991f0c6f();
    finalize();
}

void f_dd272cd7(inout vec4 vertex) {
    f_2ff19491();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_6ff1481c(vertex);
    finalize();
}

void f_c0d59038(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_991f0c6f();
    f_6ff1481c(vertex);
    finalize();
}

void f_df63a687(inout vec4 vertex, float speed) {
    f_6ff1481c(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_92e9d7a7(inout vec4 vertex) {
    f_6ff1481c(vertex);
    f_2ff19491();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_ab98f1b1(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_2ff19491();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_6ff1481c(vertex);
            f_2ff19491();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_6ad6c92c(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_6ad6c92c(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_dd272cd7(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_dd272cd7(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_df63a687(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_92e9d7a7(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_5a9aac0f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_6ad6c92c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_b453f38b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_dd272cd7(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_c0d59038(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_df63a687(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_5a9aac0f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_6ad6c92c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_b453f38b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_dd272cd7(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_c0d59038(vertex);
        return;
    }
    

    
    f_6ff1481c(vertex);
    f_2ff19491();
    finalize();
}