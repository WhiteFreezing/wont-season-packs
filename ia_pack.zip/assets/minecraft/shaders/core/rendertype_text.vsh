#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_46012f1c(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_8e66d1dd() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_b4918218(inout vec4 vertex) {
    f_46012f1c(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_8e66d1dd();
    }
    finalize();
}



void f_8fe38a23() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_717b384b() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_3c67da40(inout vec4 vertex) {
    f_46012f1c(vertex);
    f_8fe38a23();
    finalize();
}

void f_cafe475e(inout vec4 vertex) {
    f_46012f1c(vertex);
    f_8e66d1dd();
    f_717b384b();
    finalize();
}

void f_a539a202(inout vec4 vertex) {
    f_46012f1c(vertex);
    f_717b384b();
    f_8fe38a23();
    finalize();
}

void f_11f541a8(inout vec4 vertex) {
    f_8e66d1dd();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_46012f1c(vertex);
    finalize();
}

void f_85325691(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_8fe38a23();
    f_46012f1c(vertex);
    finalize();
}

void f_80ab11e7(inout vec4 vertex, float speed) {
    f_46012f1c(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_976b5d59(inout vec4 vertex) {
    f_46012f1c(vertex);
    f_8e66d1dd();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_b4918218(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_8e66d1dd();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_46012f1c(vertex);
            f_8e66d1dd();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_cafe475e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_cafe475e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_11f541a8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_11f541a8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_80ab11e7(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_976b5d59(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_3c67da40(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_cafe475e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_a539a202(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_11f541a8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_85325691(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_80ab11e7(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_3c67da40(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_cafe475e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_a539a202(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_11f541a8(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_85325691(vertex);
        return;
    }
    

    
    f_46012f1c(vertex);
    f_8e66d1dd();
    finalize();
}